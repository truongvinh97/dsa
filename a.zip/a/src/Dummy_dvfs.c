#include <Dummy_core.h>

/*--------------------------------------------*
 * 				  PROTOTYPE				  *
 *--------------------------------------------*/
	int io_open (resmgr_context_t *ctp, io_open_t  *msg, RESMGR_HANDLE_T *handle, void *extra);
	int io_read (resmgr_context_t *ctp, io_read_t  *msg, RESMGR_OCB_T *ocb);
	int io_write(resmgr_context_t *ctp, io_write_t *msg, RESMGR_OCB_T *ocb);


	resmgr_connect_funcs_t  connect_funcs;
	resmgr_io_funcs_t       io_funcs;
	char data[255] = "";


	dispatch_t              *dpp;
	resmgr_attr_t           rattr;
	dispatch_context_t      *ctp;
	iofunc_attr_t           ioattr;

	char    *progname = "Nothing\n";
	int     optv;

/*--------------------------------------------*
 * 		START RESOURCE MANAGER				  *
 *--------------------------------------------*/
int main (int argc, char **argv)
	{
		int pathID;

/* Allocate and initialize a dispatch structure */

		dpp = dispatch_create ();
		if (dpp == NULL) {
			fprintf (stderr, "%s:  couldn't dispatch_create: %s\n",
					progname, strerror (errno));
			exit (1);
		}

/* Initialize resource manager attributes */
		memset (&rattr, 0, sizeof (rattr));

/* Initialize functions for handling messages */
		iofunc_func_init (_RESMGR_CONNECT_NFUNCS, &connect_funcs,
				_RESMGR_IO_NFUNCS, &io_funcs);

/* Override the default function pointers with some of our own coded functions */
//		connect_funcs.open = io_open;
		io_funcs.read = io_read;
		io_funcs.write = io_write;

/* Initialize attribute structure used by the device */
		iofunc_attr_init (&ioattr, S_IFCHR | 0666, NULL, NULL);
		ioattr.nbytes = strlen (progname)+1;
/* Attach our device name */
		pathID = resmgr_attach (dpp, &rattr, "/dev/dvfs",
				_FTYPE_ANY, 0, &connect_funcs, &io_funcs, &ioattr);
		if (pathID == -1) {
			fprintf (stderr, "%s:  couldn't attach pathname: %s\n",
					progname, strerror (errno));
			exit (1);
		}

/* Allocate a context structure */
		ctp = dispatch_context_alloc (dpp);

/* Start the resource manager message loop */
		while (1) {
			if ((ctp = dispatch_block (ctp)) == NULL) {
				fprintf (stderr, "%s:  dispatch_block failed: %s\n",
						progname, strerror (errno));
				exit (1);
			}

			dispatch_handler (ctp);
		}
	}

/*--------------------------------------------*
 * 				  IO OPEN				      *
 *--------------------------------------------*/

int io_open (resmgr_context_t *ctp, io_open_t *msg, RESMGR_HANDLE_T *handle, void *extra)
	{
		if (optv) {
			printf ("%s:  in io_open\n", progname);
		}

		return (iofunc_open_default (ctp, msg, handle, extra));
	}

/*--------------------------------------------*
 * 				  IO READ				      *
 *--------------------------------------------*/
int io_read (resmgr_context_t *ctp, io_read_t *msg, RESMGR_OCB_T *ocb)
{
    int         nleft;
    int         nbytes;
    int         nparts;
    int         status;

    if ((status = iofunc_read_verify (ctp, msg, ocb, NULL)) != EOK)
        return (status);

    if ((msg->i.xtype & _IO_XTYPE_MASK) != _IO_XTYPE_NONE)
        return (ENOSYS);

    /*
     *  On all reads (first and subsequent), calculate
     *  how many bytes we can return to the client,
     *  based upon the number of bytes available (nleft)
     *  and the client's buffer size
     */

    nleft = ocb->attr->nbytes - ocb->offset;
    nbytes = min (msg->i.nbytes, nleft);

    if (nbytes > 0) {
        /* set up the return data IOV */
        SETIOV (ctp->iov, progname + ocb->offset, nbytes);

        /* set up the number of bytes (returned by client's read()) */
        _IO_SET_READ_NBYTES (ctp, nbytes);

        /*
         * advance the offset by the number of bytes
         * returned to the client.
         */

        ocb->offset += nbytes;

        nparts = 1;
    } else {
        /*
         * they've asked for zero bytes or they've already previously
         * read everything
         */

        _IO_SET_READ_NBYTES (ctp, 0);

        nparts = 0;
    }

    /* mark the access time as invalid (we just accessed it) */

    if (msg->i.nbytes > 0)
        ocb->attr->flags |= IOFUNC_ATTR_ATIME;

    return (_RESMGR_NPARTS (nparts));
}

/*--------------------------------------------*
 * 				  IO WRITE				      *
 *--------------------------------------------*/

int io_write(resmgr_context_t *ctp, io_write_t *msg, RESMGR_OCB_T *ocb) {
	int nb = 0;

	if(msg->i.nbytes == ctp->info.msglen - (ctp->offset + sizeof(*msg))) {
		char *buf;
		buf = (char *)(msg+1);

		if(strstr(buf, "cpuusage") != NULL) {

				get_cpu_usage();
				progname = "CPU usage\n";

		}

		else if(strstr(buf, "cpuinfo") != NULL){
			get_cpu_info();
			progname = "CPU info\n";
		}

		else if(strstr(buf, "cpufreq") != NULL){
			get_cpu_freq();
			progname = "CPU freq\n";
		}

		else {
			strcpy(data, buf);

		}

		nb = msg->i.nbytes;
	}

	_IO_SET_WRITE_NBYTES (ctp, nb);
	if (msg->i.nbytes > 0)
		ocb->attr->flags |= IOFUNC_ATTR_MTIME | IOFUNC_ATTR_CTIME;

	return (_RESMGR_NPARTS (0));
}
