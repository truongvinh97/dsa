#ifndef _DUMMY_CORE_H_
#define _DUMMY_CORE_H_

	#include <errno.h>
	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <unistd.h>
	#include <sys/iofunc.h>
	#include <sys/dispatch.h>
	#include <sys/neutrino.h>
	#include <sys/resmgr.h>

	#include <atomic.h>
	#include <libc.h>
	#include <pthread.h>
	#include <sys/iofunc.h>
	#include <sys/syspage.h>
	#include <unistd.h>
	#include <inttypes.h>
	#include <sys/types.h>
	#include <sys/debug.h>
	#include <sys/procfs.h>
	#include <sys/syspage.h>
	#include <sys/time.h>
	#include <time.h>
	#include <fcntl.h>
	#include <devctl.h>
	#include <errno.h>
	#include <inttypes.h>

/*--------------------------------------------*
 * 				  PROTOTYPE			  		  *
 *--------------------------------------------*/
void get_cpu_usage();
void get_cpu_info();
void get_cpu_freq();

#endif /* _DUMMY_CORE_H_ */

